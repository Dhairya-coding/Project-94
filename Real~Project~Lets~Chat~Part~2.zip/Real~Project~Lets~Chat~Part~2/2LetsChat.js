const firebaseConfig = {
  apiKey: "AIzaSyDTRxDKrFs4ZMLKnI63_z_g99hsn7Bxo44",
  authDomain: "lets-chat-39432.firebaseapp.com",
  databaseURL: "https://lets-chat-39432-default-rtdb.firebaseio.com",
  projectId: "lets-chat-39432",
  storageBucket: "lets-chat-39432.appspot.com",
  messagingSenderId: "433275597081",
  appId: "1:433275597081:web:0e4c17b81aba1b65541588"
};

firebase.initializeApp(firebaseConfig);

localStorage.setItem("user_name", user_name);
user_name = localStorage.getItem("user_name");

document.getElementById("welcome_message").innerHTML = "Welcome " + user_name + "!";

function logout() {
    window.location = "1LetsChat.html";
  }

  function addRoom() {
    room_name = document.getElementById("room_name").value;
    firebase.database().ref("/").child(room_name).update({
      purpose : "adding Room"
   });   

    localStorage.setItem("room_name", room_name);

    document.getElementById("room_name").innerHTML = "";

    window.location = "3LetsChat.html";
 } 

 function getData() {
  firebase.database().ref("/").on('value', function(snapshot) {
  document.getElementById("output").innerHTML = "";
  snapshot.forEach(function(childSnapshot) {
  childKey  = childSnapshot.key;
  Room_names = childKey;
  console.log("Room Name - "+ Room_names);
  row = "<div class='room_name' id="+ Room_names + "onclick='redirectToRoomName(this.id)'> #" +Room_names + "</div><hr>";
  document.getElementById("output").innerHTML = row;
  });});}
getData();

function redirectToRoomName(name_room) {
  console.log(name_room);
  localStorage.setItem("room_name", name_room);
  window.location = "3LetsChat.html";
}