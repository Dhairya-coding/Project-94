const firebaseConfig = {
  apiKey: "AIzaSyDTRxDKrFs4ZMLKnI63_z_g99hsn7Bxo44",
  authDomain: "lets-chat-39432.firebaseapp.com",
  databaseURL: "https://lets-chat-39432-default-rtdb.firebaseio.com",
  projectId: "lets-chat-39432",
  storageBucket: "lets-chat-39432.appspot.com",
  messagingSenderId: "433275597081",
  appId: "1:433275597081:web:0e4c17b81aba1b65541588"
};

localStorage.setItem("user_name", user_name);
user_name = localStorage.getItem("user_name");

firebase.initializeApp(firebaseConfig);

function login() {
    user_name = document.getElementById("user_name").value;
    localStorage.setItem("user_name", user_name);
    window.location = "2LetsChat.html";

    firebase.database().ref("/").child(user_name).update({
        purpose : "adding User"
    });
 }